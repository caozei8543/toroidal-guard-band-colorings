# Release notes, version 1.0.0 — 2026-11-10

## What is shipped

- Complete published-manuscript-associated prior 16-case auditor and original log (historical snapshots).
- Reworked standard-library verification package with 18 positive cases and explicitly separated provenance groups.
- Additional order-20 ordinary Skolem pairing and two `d=4` fixtures from the manuscript's Table V; *new numerical checks, not new theorems*.
- Six expected-rejection controls (the first three preserve the prior paper's seam tests).
- Complete color assignments for all vertices and all undirected edges in all 18 cases; phase/offset tables; machine-readable results and logs.
- A separate CSV-only checker, unit tests, and exact finite Lee clique witnesses.
- Final author-supplied manuscript (DOCX and rendered PDF) and the Chinese editorial audit memo as background documentation.

## Critical checks prior to a public GitHub/Zenodo deposit

1. Verify the author's identity, ownership, coauthor permissions if applicable, and the copyright line in `LICENSE`. The provisional MIT terms apply to code/data/documentation generated for this reproducibility release, **not** the Word/PDF manuscript. This repository does not grant publication rights to third-party articles or journal content.
2. Verify any journal policy about submission, preprints, supplementary material, or publicly releasing the manuscript before publication. Remove `manuscript/` if necessary; the code/data remain fully reproducible without it.
3. Fill in an actual repository URL and an actual DOI *only after one has been allocated*. None are fabricated in `CITATION.cff`.
4. Upload the **contents** of this folder as a repository (do not publish `__pycache__` folders) and retain `README.md`, `README_中文.md`, `LICENSE`, and `CITATION.cff` at the repository root.
5. On a clean machine, run `python tools/verify_checksums.py` **before** regenerating output, then rerun `run_audit.py`, `verify_exports.py`, and unit tests.
6. If any program, mathematical formula, input table, or manuscript content is changed after this release, rerun both auditors and regenerate the checksum manifest for a new tagged version.

## Honest scope

This software demonstrates feasible constructive label assignments and finite local geometric witnesses. It is not a general-purpose optimization solver, a proof assistant, a verified universal Skolem sequence generator, or a substitute for peer review. Claims of universal exactness, novelty, performance in real radio networks, or the likelihood of acceptance cannot be inferred from passing tests.
