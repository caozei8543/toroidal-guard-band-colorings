# Reproducibility and evidentiary limits

## Exact reproducibility claims

1. The archived historical script `archive/previous_scripts/torus_guard_band_independent_audit.py` reprints the previously supplied 16-case log and, on the supplied environment, reproduces its headline totals **2,336,334** incident-edge comparisons and **157,876** directed edge labels.
2. `run_audit.py` independently consumes versioned JSON fixtures and stored difference-pair certificates. It audits the complete graph for each case: enumerates *all* directed steps, both endpoint label evaluations, every incident vertex–edge separation, every adjacent vertex pair and every unordered pair of edges incident at the same vertex.
3. `verify_exports.py` is a separate CSV reader and checker. It builds the graph edges again using the integer Lee ball, compares with exported edge keys, checks exact vertex degree and all three integer separation types; no constructor is imported from the main package.
4. `tests/test_certificates.py` validates: Lee interval for radii 1–12, all five pairing tables, the generator-reversal identity, positive and invalid cases, the palette counts, and finite cliques for radii 1–10.
5. The `original16` and `supplemental2` counts are always separate. The d=4 Skolem order-20 pairing is a newly stored finite certificate obtained by deterministic exact integer backtracking, not an assumption that every ordinary Skolem order exists.
6. No source table is randomly sampled, and there is no floating-point tolerance or optimization solver.

## Limitations

- The empirical tests are finite. They do **not** prove that the equalities hold for every admissible torus; consult the complete mathematical proof and all hypotheses in the manuscript.
- The code checks constructive coloring feasibility. Optimality relies on separate analytic lower bounds in the manuscript, not on a chromatic-number solver.
- Period closure is sufficient for the particular phase template; rejection of a bad period does not mean that the underlying graph admits no coloring with the same palette.
- This release bundles explicit ordinary Skolem tables for orders 12 and 20, hooked tables for 2 and 6, and the special wrapped order-6 table. It does not contain a verified generic constructive solver for arbitrary sequence orders. The paper's classical existence theorems have broader scope than the finite tables in this software.
- Reverse-orientation consistency is a separate check from incident vertex–edge gap size. The `cover` construction uses an explicit quotient-edge formula rather than a generator offset table.
- Manuscript files may require particular Word/math equation fonts to render identically; scripts for historical Word-layout editing are archived for provenance and are **not** needed to reproduce mathematical results.
- `results.json` includes locally measured Python/platform metadata; exact bytes of the regenerated JSON and its SHA-256 may change across machines even when mathematical results agree. This does not change the integer audit counts or colors in exported CSV.

## Reproduction of original totals and extension

The 16 original cases use 78,938 undirected edges, 157,876 directed edge color evaluations, and 2,336,334 unordered comparisons of incident edges. Two supplemental `d=4` cases add 64,280 edges, 128,560 directed evaluations and 2,506,920 comparisons. Combined: 143,218 edges, 286,436 directed evaluations, and 4,843,254 comparisons. These are deterministic counts implied by `n*m` and `Δ=2d(d+1)`.

The negative input controls are not counterexamples to the original theorems: they intentionally *violate* their stated assumptions and must be rejected before coloring proceeds.

## Checksums and provenance

`SHA256SUMS.txt` hashes every archived release file other than the manifest itself; run `python tools/verify_checksums.py` in an **untouched extracted archive**. The `archive/` directory retains verbatim snapshots of pre-existing scripts/logs and includes intermediate manuscript-layout scripts so that no previous code is omitted from the user-facing handoff. Only `run_audit.py`, `verify_exports.py`, and `src/guardband/core.py` are the supported release audit runtime.
