# Code-to-manuscript traceability / 代码-论文对应

The Word/PDF manuscript is included in `manuscript/` as a reference; its mathematical statements govern the theory. No new theorem has been inferred from the verification program.

| Manuscript result | Implementation | Data/fixture |
|---|---|---|
| Lee phase interval, Lemma 1 | `lee_phase`, `lee_steps`, `validate_lee_interval` | Tests `d=1,...,12`; `local_offsets.csv` |
| Unified phase–offset certificate, Theorem 1 | `Construction.phase`, `.offset`, `.color_vertex`, `.color_edge`, `.opposite_offset_ok`, `audit_case` | Per-case edge/vertex CSV; exact endpoint checks |
| Cocktail-party covering, Lemma 2 / Theorem 2 | Family `cover` (explicit quotient base coloring) | `cover_d2_7x14`, `cover_d1_6x3`, `cover_d3_26x13` |
| Direct odd-phase Type I, Proposition 1 | Family `odd` | `odd_d2_13x13`, `odd_d3_25x25` |
| Hooked Skolem guard construction, Theorem 3 | Family `hooked` | Hooked K2/K6 certificates; `hooked_*` fixtures |
| Ordinary Skolem compression, Proposition 2 / Theorem 5 | Family `ordinary` | K12 and supplemental K20 certificates; `ordinary_*` fixtures |
| Weighted scaling, Corollary 1 | `Case.r/s/t` with scaling and integer thresholds | `scaled_hooked_d2_9x6` |
| Wrapped modular pairing, Proposition 3 / Theorem 6 | Family `wrapped` | `wrapped_k6_mod17.json`; `wrapped_d2_17x17` |
| Two-unit odd-modulus exact result, Theorem 4 | Family `guard2` | `guard2_*` at `d=2,3,4` |
| Explicit Lee-diameter cliques, Lemma 5 | `clique_witness`, `clique_check` | `lee_clique_witnesses.json` for d2/d3/d4 |
| Transposed period applicability, Corollary 2 | Graph definition symmetric under coordinate exchange; user can transpose input periods and corresponding phase axes explicitly | No new automated extension claim is made beyond checked cases |
| 16 verification fixtures, Section VII | Archived original auditor plus `run_audit.py` | `group=original16`; archived historical log; reproduced exact totals |
| Table V d=4 rows | Bundled ordinary K20 sequence plus `run_audit.py` | `group=supplemental2`, **additional** verification; not counted as original 16 |

## Precise construction formulas used

Let `K=d(d+1)`, `Δ=2K`, `λ(x,y)=dx+(d+1)y`. With each formula reduced modulo the stated `M` before interpreting it as a nonnegative integer color:

- `cover`: `p=K+1`, `M=2p`, phase `λ mod M`, covering target is a cocktail-party graph on `2p` phase vertices and `2p−1` *colors*. Write phase as `(layer,i)` where `layer in {0,1}` and `i in {0,...,p−1}`. Vertex color `i`. Within-layer edge color `(i+j)*2^{-1} mod p`. Cross-layer edge color `p+((j−i) mod p)−1` where `i` is the layer-0 index and `j` the layer-1 index.
- `odd`: `M=2K+1`, vertex color `2λ(x) mod M`, edge color `2λ(x)+λ(z) mod M`.
- `guard2`: `M=2K+3`, vertex color `4λ(x) mod M`, edge color `4λ(x)+2λ(z) mod M`.
- `hooked`: `M=2K+2u`, vertex color `λ(x) mod M`, edge offset `u−1 + [b_h if λ(z)>0 else a_h]`, where `b_h−a_h=h` and hooked positions partition `{1,...,2K−1,2K+1}`.
- `ordinary`: `M=2K+2u−1`, otherwise identical offset rule, using the ordinary positions `{1,...,2K}`.
- `wrapped`: exclusively `d=2,u=3,M=17`, offset `[b_h if λ(z)>0 else a_h]` from the six modularly paired differences, covering the whole interval `3,...,14`.

All families check the two period congruences `(phase_factor*d*n) mod M == 0`, `(phase_factor*(d+1)*m) mod M == 0`; for `cover` the phase factor is 1. The covering formula is separately checked for orientation equality and integer properness. All labels may be multiplied by the scaling factor `s` when `r<=s`, `t<=s*base_guard`, and palette is adjusted to `(base_palette−1)*s+1`.

`run_audit.py` checks **feasibility**; the manuscript proves **optimality** for some families via matching lower bounds. The code's finite cliques are useful regression witnesses but not a formal check of the published clique formula for every `d`.
