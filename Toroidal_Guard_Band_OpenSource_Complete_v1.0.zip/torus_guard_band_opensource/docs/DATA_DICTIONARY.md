# Data dictionary / 数据字典

All files are UTF-8. JSON is plain schema-versioned JSON; CSV uses comma-separated headers with integer decimal values and one header row. No missing-color sentinel is used. There are no externally downloaded datasets.

## Input files

### `data/fixtures/positive_cases.json`

Top-level `{ "schema_version": "1.0", "cases": [ ... ] }`. Case fields:

| Field | Meaning |
|---|---|
| `id` | Stable ASCII unique identifier, also the name of the export subdirectory |
| `group` | `original16` = case in the previous manuscript audit; `supplemental2` = separately generated new checks |
| `family` | `cover`, `odd`, `guard2`, `hooked`, `ordinary`, or `wrapped` |
| `d` | Lee graph radius; positive integer |
| `n`, `m` | Periods of the first and second Cartesian-cycle coordinates |
| `u` | Base integer guard parameter used by the relevant construction (1 for Type I) |
| `palette` | Number of consecutive integer labels, with actual assigned colors in `0,...,palette-1` |
| `r` | Required difference between adjacent vertex colors |
| `s` | Required difference between colors of edges sharing a vertex |
| `t` | Required difference between an incident vertex and edge |

All periods obey `n,m >= 2*d+1` and family-specific congruences before any graph is enumerated. For scaling, `s>=1`, `0<=r<=s`, and `t<=s*u` (or the family-specific base guard). The program checks these restrictions and rejects invalid inputs.

### `data/fixtures/negative_cases.json`

All fields above plus `expected_error` substring. These are intentionally invalid inputs: each must raise the listed `ValueError`. The original paper describes the first three rejected seam-closure controls; the other three validation controls were added to the release and are not attributed to that original audit.

### `data/certificates/*.json`

A `description` plus `pairs: [{"h":integer,"a":integer,"b":integer},...]` for every `h=1,...,K`, where `K=d(d+1)`.

For ordinary/hooked, `b-a=h` over the integers and the occupied positions partition the appropriate classic position set. For wrapped K=6, `b-a ≡ h (mod 17)` with all positions exactly `3,...,14`. All tables are mechanically revalidated on every run.

## Full per-case exports

### `data/generated/assignments/<id>/vertices.csv`

One row per vertex, exactly `n*m` rows.

| Column | Meaning |
|---|---|
| `x`, `y` | Canonical representative coordinates, `0<=x<n`, `0<=y<m` |
| `phase_residue` | Construction phase modulo its modulus; for the covering construction the phase ranges over `0,...,2(K+1)-1` |
| `vertex_color` | Assigned *ordinary integer* vertex color after any scaling |

### `data/generated/assignments/<id>/edges.csv`

One row per distinct undirected edge, canonical endpoint order `vertex1 < vertex2` lexicographically. Exactly `n*m*d*(d+1)` rows are expected.

| Column | Meaning |
|---|---|
| `vertex1_x`, `vertex1_y` | First endpoint coordinates |
| `vertex2_x`, `vertex2_y` | Other endpoint coordinates |
| `step_from_vertex1_dx`, `step_from_vertex1_dy` | Unique local Lee step `z` satisfying `vertex1+z ≡ vertex2 (mod n,m)` |
| `edge_color_from_vertex1` | Integer edge label evaluated at first endpoint |
| `edge_color_from_vertex2` | Integer edge label evaluated using opposite generator at second endpoint; must equal preceding field |
| `vertex1_color`, `vertex2_color` | Endpoint vertex colors, for independent checks |

### `data/generated/assignments/<id>/local_offsets.csv`

A row for each nonzero Lee generator (i.e. `Δ=2d(d+1)` rows).

| Column | Meaning |
|---|---|
| `step_dx`, `step_dy` | Signed Lee generator |
| `lee_phase` | `d*step_dx+(d+1)*step_dy` in the integers |
| `phase_shift_modulo` | Shift of the actual vertex phase (possibly scaled, per family) in the chosen modular ring |
| `offset_modulo_or_blank` | Local edge offset modulo ring; blank for `cover` which colors quotient-graph edges by explicit base formulas |

### `data/generated/assignments/<id>/summary.json`

Full audit result for the case; fields are as defined in the aggregate result below.

## Results and logs

`data/generated/results.csv` contains one row per positive case. `data/generated/results.json` contains the complete per-case records, group-level sums, all negative controls, all clique points, and platform metadata. Main fields:

| Field | Meaning |
|---|---|
| `vertices`, `edges`, `degree` | Graph combinatorial counts `nm`, `nmΔ/2`, `Δ` |
| `directed_edge_evaluations` | Two evaluations per undirected edge |
| `edge_edge_comparisons` | All `nm*binom(Δ,2)` unordered incident-edge pairs |
| `min_vertex_vertex_gap` | Minimum ordinary absolute difference over adjacent vertices |
| `min_edge_edge_gap` | Minimum ordinary absolute difference over incident-edge pairs |
| `min_vertex_edge_gap` | Minimum ordinary absolute difference over *both endpoint* incidences |
| `opposite_offset_identity` | `true` if phase-offset reverse-generator identity holds; `null` for covering graph (different rule) |
| `failures` | Six counters: orientation, cardinality, range, vertex_vertex, edge_edge, vertex_edge |
| `total_failures` | Sum of the six counters |
| `status` | `PASS` only if sum of violations is zero |

The checks compare actual integer color representatives directly, *not* circular distances. A lack of failures in these finite instances does not establish exactness over arbitrary torus periods.

`data/generated/negative_controls.json` reports input checks that are **rejected** as intended; `data/generated/lee_clique_witnesses.json` includes the exact coordinates of constructed finite cliques and computed diameters. `logs/reproduction_all_18.txt` is complete stdout of the 18-case runner, `logs/independent_export_verification.txt` is CSV-only verification stdout, and `logs/unit_tests.txt` is test suite output. `archive/previous_logs/audit_16_cases.txt` is an untouched copy of the original previous-turn 16-case report.

## Sizes and totals

18 case directories × 4 exports each = 72 files. The case data contain **9,072 vertex rows** and **143,218 undirected-edge rows**, together with complete local offset tables, including duplicate vertices across differently colored fixtures when they are logically distinct experiments. Do not deduplicate experiments because they may use different parameter sets and palettes.

## Direct paper table transcriptions

- `data/fixtures/paper_table_v.csv`: all six numerical rows in manuscript Table V, with each row linked by `case_id` to the output and annotated as original or supplemental verification.
- `data/fixtures/paper_table_vi.csv`: all ten numerical audit rows in manuscript Table VI, with the table's `N`, `E`, `L`, `g`, and `F` as independently comparable integers.
- `python tools/compare_paper_tables.py` verifies every table row against the generated numeric JSON; `python tools/compare_historical_results.py` checks all 16 original records (including pair counts and all six failure counters) against the untouched original 16-case text log.
