#!/usr/bin/env bash
# Recompute all 18 cases and check CSV exports. Run from any directory.
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
echo '1/6 Verify release hashes (pristine archive only)...'
"$PYTHON_BIN" tools/verify_checksums.py
echo '2/6 Reproduce all constructive cases and export full assignments...'
"$PYTHON_BIN" run_audit.py --export-assignments --output data/generated
echo '3/6 Verify CSV assignments independently...'
"$PYTHON_BIN" verify_exports.py --input data/generated
echo '4/6 Compare against the original 16-row historical log...'
"$PYTHON_BIN" tools/compare_historical_results.py
echo '5/6 Cross-check Table V and Table VI...'
"$PYTHON_BIN" tools/compare_paper_tables.py
echo '6/6 Run unit tests...'
"$PYTHON_BIN" -m unittest discover -s tests -v
echo 'ALL CHECKS PASSED'
