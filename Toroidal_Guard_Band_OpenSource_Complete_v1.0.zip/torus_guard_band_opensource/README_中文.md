# 环面网格幂图精确保护间隔染色：开源复现包（中文指南）

本仓库对应论文 **Exact Guard-Band Colorings of Toroidal Grid Powers via Lee Cliques and Modular Difference Pairings**，作者 Weibiao Zhang（以所提供稿件为准，未虚构 DOI、期刊录用信息）。这是包含**源码 + 原始日志 + 全量顶点边染色数据 + 复现实验 + 测试 + 论文对照材料**的可运行开源发布包，不只是一个汇总表。

## 1. 直接运行

安装 Python 3.10 及以上即可，运行审计不需要第三方 Python 包、网络、绘图软件或求解器。在解压后的仓库根目录执行：

```bash
# 重新生成18个例子的CSV、结构化汇总和完整整数染色记录
python run_audit.py --export-assignments --output data/generated

# 另一个独立脚本不调用染色构造，直接审核CSV图结构与色差
python verify_exports.py --input data/generated

# 运行8项单元测试
python -m unittest discover -s tests -v

# 建议在运行前执行，用于核对压缩包中的原始文件完整性
python tools/verify_checksums.py
```

只运行**原论文报告的16例**：

```bash
python run_audit.py --original-only --output original16_output
```

历史版原始程序亦完整保留：

```bash
python archive/previous_scripts/torus_guard_band_independent_audit.py
```

## 2. 已有验证与新增验证必须区分

- **原论文16个正例**：全部通过。157,876 次有向边着色计算，2,336,334 次相邻边颜色配对核查；保留原始 `archive/previous_logs/audit_16_cases.txt`，能直接核对上一轮结果。
- **本次另外新增2个正例**：论文 Table V 中的 `d=4, u=3, (n,m)=(45,9), 45色` 和 `d=4, u=7, (n,m)=(53,53), 53色`；均通过，新增 128,560 次有向边计算和 2,506,920 次相邻边颜色检查。新增结果**不应倒写成原论文声称的16项之一**。
- **总计18例**：143,218 条无向边、286,436 次有向边着色、4,843,254 次相邻边配对，六类违规计数均为零。
- **负例输入**：论文的三个周期闭合失败控制，以及额外三个输入有效性控制；共6个，均按预期拒绝。它们不能计入染色成功数量。
- **下界几何证书**：`d=2,3,4` 对应显式团大小 `5,8,13`，有限枚举校验了所有点对的 Lee 距离。

注意：此处核验的是**有限具体染色实例及下界的有限几何见证**；无限族的存在性与最优性仍然由正文数学证明承担。程序并不声称在所有周期上得到全局最优染色，也不声称古典 Skolem 序列是原创算法。

## 3. 重要文件位置

| 内容 | 文件或目录 |
|---|---|
| 完整核心染色构造和审计 | `src/guardband/core.py` |
| 一键运行全部实验 | `run_audit.py` |
| 第二套 CSV 独立检验 | `verify_exports.py` |
| 单元测试 | `tests/test_certificates.py` |
| 正例/负例的全部输入 | `data/fixtures/positive_cases.json`、`negative_cases.json` |
| Skolem、hooked、wrapped 配对 | `data/certificates/` |
| 18例全部结果 JSON/CSV | `data/generated/results.json`、`results.csv` |
| 每例全部顶点、边、偏移数据 | `data/generated/assignments/<案例名>/` |
| 拒绝负例和显式团证书 | `data/generated/negative_controls.json`、`lee_clique_witnesses.json` |
| 完整运行日志、独立校验日志、测试日志 | `logs/` |
| 原16例脚本与原始日志及历史排版脚本 | `archive/` |
| 论文 Word/PDF 对照文件 | `manuscript/` |
| 数据信息、论文章节对应、风险说明 | `docs/` |
| 全量文件 SHA-256 清单 | `SHA256SUMS.txt` |

**三个最重要的 CSV：** `vertices.csv`（每个顶点坐标、相位和顶点颜色）；`edges.csv`（每条无向边两个端点、从首端点看到的 Lee 步、从两个端点计算的边颜色、两端点颜色）；`local_offsets.csv`（每种 Lee 步和模偏移）。全部实例数据保留，没有仅抽样10行或只保留汇总。

## 4. 可核查的构造机制

- Lee 相位 `λ(a,b)=d*a+(d+1)*b`，顶点数 `nm`，度数 `Δ=2d(d+1)`；周期条件逐例检验。
- 两种普通总染色 `cover` 与 `odd`；二单位间隔 `guard2`；一般 `hooked`、`ordinary`；`d=2,u=3` 的 17 色 `wrapped` 模差表；加权缩放配置。
- 全部数字颜色先取模得到 `0,...,M-1` 的**整数代表元**，再逐个检查顶点–顶点、边–边、端点–边的**普通整数差值**；绝不以环距离取代整数保护间隔定义。
- 无向边从两个端点分别计算，直接比较颜色；全部边的集合与另一套不依赖着色代码的 Lee 邻接生成器再次比较。

## 5. 开源之前需要确认

仓库的核心程序、数据、日志与新撰写文档使用 MIT 许可证草案；**论文 DOCX/PDF 不包含在 MIT 授权范围内**，可根据作者及期刊的版权要求决定保留或删除。请确认作者/共同作者授权、许可证署名、论文是否已投稿或发表、期刊预印本政策、仓库链接及 DOI。`CITATION.cff` 暂不填写不存在的 DOI。

参见 [数据字段说明](docs/DATA_DICTIONARY.md)、[公式/定理对照](docs/METHOD_TO_PAPER.md)、[复现边界说明](docs/REPRODUCIBILITY.md) 和 [开源前清单](RELEASE_NOTES.md)。

## 6. GitHub 一键复验与论文原表逐行核对

Windows 可执行 `run_all.bat`，macOS/Linux 可运行 `bash run_all.sh`，启动完整六步校验流程。仓库附带 GitHub Actions 配置 `.github/workflows/reproduce.yml`，公开后每次推送或 Pull Request 均可重新跑全部检查。`data/fixtures/paper_table_v.csv` 保留论文表 V 的六行精确实例；`paper_table_vi.csv` 保留论文表 VI 的十行实验记录，并通过 `tools/compare_paper_tables.py` 自动与复现结果逐行对照。`tools/compare_historical_results.py` 更会检查**原始16例日志的每一行**，而非只比较总计数字。
