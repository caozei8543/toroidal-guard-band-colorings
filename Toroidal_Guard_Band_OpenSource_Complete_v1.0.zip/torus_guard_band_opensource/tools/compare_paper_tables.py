#!/usr/bin/env python3
"""Verify manuscript Table V and VI CSV transcriptions against generated results."""
import csv
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
results=json.loads((ROOT/'data/generated/results.json').read_text(encoding='utf8'))
cases={r['id']:r for r in results['cases']}
for table in ('v','vi'):
    path=ROOT/f'data/fixtures/paper_table_{table}.csv'
    with path.open(newline='',encoding='utf8') as fh:
        records=list(csv.DictReader(fh))
    for row in records:
        entry=cases[row['case_id']]
        fields=('d','u','n','m','palette') if table=='v' else ('d','u','n','m','vertices','edges','palette','min_vertex_edge_gap','total_violations')
        for field in fields:
            lookup='total_failures' if field=='total_violations' else field
            assert int(row[field])==entry[lookup],f'Table {table.upper()} row {row["case_id"]}: {field}'
        if table=='v':
            assert row['verification_group']==entry['group']
            d=entry['d']
            kappa=(d*d+2*d+2)//2 if d%2==0 else (d+1)*(d+1)//2
            assert int(row['clique_order'])==kappa
    print(f'Table {table.upper()}: PASS {len(records)} rows checked')
