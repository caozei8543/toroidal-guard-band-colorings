#!/usr/bin/env python3
"""Rebuild the explicit pairing tables and fixture inputs from archived source.

This is an optional provenance script. Running it overwrites certificate and
fixture JSON; it intentionally does not modify the archived 16-case script.
"""
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'archive'/'previous_scripts'))
from torus_guard_band_independent_audit import H2,H6,W6,O12,find_skolem


def main():
    cert=ROOT/'data'/'certificates'
    records=[
      ('hooked_k2.json','Hooked Skolem order 2 (finite certificate)',H2),
      ('hooked_k6.json','Hooked Skolem order 6 (paper Table II)',H6),
      ('ordinary_k12.json','Ordinary Skolem order 12 (original 16-case auditor)',O12),
      ('ordinary_k20.json','Ordinary Skolem order 20 (supplemental d=4 verification)',find_skolem(20)),
      ('wrapped_k6_mod17.json','Wrapped residue pairing modulo 17 (paper Table III)',W6)]
    for file,description,pairs in records:
        obj={'description':description,'pairs':[{'h':h,'a':a,'b':b} for h,(a,b) in sorted(pairs.items())]}
        (cert/file).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf8')
    print('Recreated',len(records),'difference-pair certificate files.')
    print('The 18 positive and 6 negative fixtures are intentionally versioned JSON and are not regenerated.')

if __name__=='__main__':main()
