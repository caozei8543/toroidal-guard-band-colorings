#!/usr/bin/env python3
"""Compare all 16 historical log records to new machine-readable audit data."""
import ast
import json
import pathlib
import sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
log=(ROOT/'archive/previous_logs/audit_16_cases.txt').read_text(encoding='utf8')
data=json.loads((ROOT/'data/generated/results.json').read_text(encoding='utf8'))
original=[r for r in data['cases'] if r['group']=='original16']
rows=[]
for line in log.splitlines():
    if line.startswith("('"):
        tup,_,f=line.partition(' violations ')
        rows.append((ast.literal_eval(tup),ast.literal_eval(f)))
if len(rows)!=16 or len(original)!=16:
    raise SystemExit('FAIL: 16 historical and new records required')
for idx,((prev,old_fail),new) in enumerate(zip(rows,original),1):
    family,(d,u),(n,m),count,colors,minve,minvv,minee,fail_total,ee_pairs=prev
    expected=(new['family'],new['d'],new['u'],new['n'],new['m'],
              f"{new['vertices']}/{new['edges']}",new['palette'],
              new['min_vertex_edge_gap'],new['min_vertex_vertex_gap'],
              new['min_edge_edge_gap'],new['total_failures'],new['edge_edge_comparisons'])
    observed=(family,d,u,n,m,count,colors,minve,minvv,minee,fail_total,ee_pairs)
    if observed!=expected or old_fail!=new['failures']:
        print(f'FAIL historical record {idx}: old={observed} new={expected} failure dict={old_fail}/{new["failures"]}')
        sys.exit(1)
print('PASS: All 16 historical log records match new results exactly: family, radius, guard, period, V/E, palette, all three minimum margins, six failure counters, pair comparisons.')
