#!/usr/bin/env python3
"""Run the published 16-case reproduction, optional additional fixtures, and controls.

Default: all 18 cases + 6 rejection controls + Lee-clique witnesses. No
third-party packages or network needed. Re-running replaces generated files.
"""
from __future__ import annotations
import argparse
import csv
import json
import platform
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from guardband.core import Case, Construction, audit_case, clique_check


def load_cases(path:Path)->list[dict]:
    data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('schema_version') != '1.0' or not isinstance(data.get('cases'),list):
        raise ValueError('Unsupported fixtures JSON schema')
    return data['cases']


def run(output:Path,original_only:bool=False,export_assignments:bool=False)->int:
    output.mkdir(parents=True,exist_ok=True)
    all_cases=load_cases(ROOT/'data/fixtures/positive_cases.json')
    if original_only:
        all_cases=[x for x in all_cases if x['group']=='original16']
    results=[]
    print('Toroidal guard-band constructive certificate auditor, v1.0.0')
    print(f'Python: {platform.python_version()}, executable: {sys.executable}')
    print('All gaps use integer color representatives, not circular distance.')
    print('Case groups: original16=previous manuscript audit; supplemental2=new d=4 checks.')
    failed=False
    for row in all_cases:
        case=Case.from_dict(row)
        # Standalone output location determined by a fixture with strictly safe ID.
        import re
        if not re.fullmatch(r'[A-Za-z0-9_-]+',case.id):
            raise ValueError('Unsafe case ID')
        dest=output/'assignments'/case.id if export_assignments else None
        result=audit_case(case,dest)
        results.append(result)
        if result['status']!='PASS':failed=True
        print(f"{case.id:31} {result['status']} "
              f"V={result['vertices']} E={result['edges']} "
              f"minimums=(VV:{result['min_vertex_vertex_gap']},EE:{result['min_edge_edge_gap']},VE:{result['min_vertex_edge_gap']}) "
              f"failure_counts={result['failures']}")
    counts={group:{'count':0,'vertices':0,'edges':0,'directed_edge_evaluations':0,'edge_edge_comparisons':0,'failures':0}
            for group in ('original16','supplemental2')}
    for row in results:
        c=counts[row['group']]
        c['count']+=1
        for fld in ('vertices','edges','directed_edge_evaluations','edge_edge_comparisons'):
            c[fld]+=row[fld]
        c['failures']+=row['total_failures']
    if counts['original16']['count']==16:
        assert counts['original16']['edge_edge_comparisons']==2336334, 'Previous 16-case edge-pair count drifted'
        assert counts['original16']['directed_edge_evaluations']==157876, 'Previous 16-case directed evaluations drifted'
    if not original_only and (counts['original16']['count']!=16 or counts['supplemental2']['count']!=2):
        raise AssertionError('Fixture set is incomplete')
    print('Group totals:',json.dumps(counts,sort_keys=True))
    control_results=[]
    for row in load_cases(ROOT/'data/fixtures/negative_cases.json'):
        test_case=Case.from_dict({k:v for k,v in row.items() if k!='expected_error'})
        expectation=row['expected_error']
        try:
            Construction(test_case)
            outcome='FAIL_NOT_REJECTED';reason='No error'
            failed=True
        except ValueError as error:
            reason=str(error)
            outcome='PASS_REJECTED' if expectation in reason else 'FAIL_WRONG_REASON'
            if outcome!='PASS_REJECTED':failed=True
        rec={'id':row['id'],'expected_error_substring':expectation,'status':outcome,'actual_message':reason}
        control_results.append(rec)
        print(f"negative {row['id']:30} {outcome}: {reason}")
    cliques=[]
    for d in (2,3,4):
        w=clique_check(d,2*d+1)
        cliques.append(w)
        if not w['valid']:failed=True
        print(f"Lee-diameter clique d={d} size={w['witness_cardinality']}, diameter={w['max_integer_lee_distance']} => {'PASS' if w['valid'] else 'FAIL'}")
    group_totals={fld:sum(g[fld] for g in counts.values()) for fld in ('count','vertices','edges','directed_edge_evaluations','edge_edge_comparisons','failures')}
    obj={'schema_version':'1.0','program_version':'1.0.0',
         'evaluation_scope':'finite explicit constructions only; not a formal proof or exhaustive search of all torus periods',
         'platform':{'python':platform.python_version(),'system':platform.system(),'machine':platform.machine()},
         'cases':results,'groups':counts,'total':group_totals,
         'negative_controls':control_results,'clique_witnesses':cliques,
         'all_checks_passed': not failed,
         'exported_assignments':bool(export_assignments)}
    (output/'results.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    fields=['id','group','family','d','u','n','m','r','s','t','modulus','palette','degree','vertices','edges',
            'directed_edge_evaluations','edge_edge_comparisons','min_vertex_vertex_gap','min_edge_edge_gap',
            'min_vertex_edge_gap','orientation','cardinality','range','vertex_vertex','edge_edge','vertex_edge',
            'total_failures','status']
    with (output/'results.csv').open('w',newline='',encoding='utf-8') as fh:
        writer=csv.DictWriter(fh,fields)
        writer.writeheader()
        for row in results:
            writer.writerow({k:row['failures'][k] if k in row['failures'] else row.get(k) for k in fields})
    (output/'negative_controls.json').write_text(json.dumps(control_results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (output/'lee_clique_witnesses.json').write_text(json.dumps(cliques,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if not original_only:
        print('EXPECTED original16: 16 cases, 2,336,334 EE comparisons; 157,876 directed labels')
    print('OVERALL:', 'PASS' if not failed else 'FAIL', group_totals)
    return 1 if failed else 0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'data'/'generated')
    parser.add_argument('--original-only',action='store_true',help='Reproduce the original 16 positive cases only')
    parser.add_argument('--export-assignments',action='store_true',help='Write full vertex, edge, and offset CSV for each case')
    args=parser.parse_args()
    return run(args.output,args.original_only,args.export_assignments)


if __name__=='__main__':
    sys.exit(main())
