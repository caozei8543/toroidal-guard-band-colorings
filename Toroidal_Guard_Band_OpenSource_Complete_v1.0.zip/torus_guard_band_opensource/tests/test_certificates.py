"""Standard-library unit tests. Run: python -m unittest discover -s tests -v"""
import json
from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from guardband.core import (Case,Construction,audit_case,clique_check,lee_steps,
                            lee_phase,validate_lee_interval,load_pair_certificate,validate_pairs,PAIR_FILES)

class LocalMathematicsTests(unittest.TestCase):
    def test_complete_lee_interval(self):
        for d in range(1,13):
            with self.subTest(d=d):
                self.assertTrue(validate_lee_interval(d))
                self.assertEqual(len(lee_steps(d)),2*d*(d+1))

    def test_pairing_tables(self):
        for (family,k),filename in PAIR_FILES.items():
            with self.subTest(family=family,k=k):
                validate_pairs(load_pair_certificate(filename),k,family)

    def test_invalid_pairing_detected(self):
        pair=load_pair_certificate('wrapped_k6_mod17.json')
        pair[1]=(12,14)
        with self.assertRaises(ValueError):
            validate_pairs(pair,6,'wrapped')

    def test_local_opposite_pair_identity(self):
        for fixture in positive_fixtures():
            con=Construction(Case.from_dict(fixture))
            if fixture['family']!='cover':
                self.assertTrue(con.opposite_offset_ok(), fixture['id'])

    def test_clique_witnesses(self):
        for d in range(1,11):
            with self.subTest(d=d):
                w=clique_check(d,2*d+1)
                self.assertTrue(w['valid'])
                self.assertEqual(w['witness_cardinality'],w['expected_cardinality'])

    def test_16_case_finite_regression_and_supplemental(self):
        # Includes checks of all directed arcs and all pairs of incident edges.
        results=[audit_case(Case.from_dict(row)) for row in positive_fixtures()]
        original=[r for r in results if r['group']=='original16']
        extra=[r for r in results if r['group']=='supplemental2']
        self.assertEqual(len(original),16)
        self.assertEqual(len(extra),2)
        self.assertEqual(sum(r['edge_edge_comparisons'] for r in original),2336334)
        self.assertEqual(sum(r['directed_edge_evaluations'] for r in original),157876)
        self.assertTrue(all(r['total_failures']==0 and r['status']=='PASS' for r in results))
        self.assertTrue(all(r['opposite_offset_identity'] in (True,None) for r in results))

    def test_expected_precheck_failures(self):
        fixture=json.loads((ROOT/'data/fixtures/negative_cases.json').read_text(encoding='utf8'))['cases']
        for row in fixture:
            with self.subTest(case=row['id']):
                name=row['expected_error']
                with self.assertRaisesRegex(ValueError,name):
                    Construction(Case.from_dict({k:v for k,v in row.items() if k!='expected_error'}))

    def test_palette_and_table_values(self):
        for row in positive_fixtures():
            c=Construction(Case.from_dict(row))
            self.assertEqual(c.c.palette,(c.base_palette-1)*row['s']+1)
            self.assertEqual(len(c.steps),c.degree)


def positive_fixtures():
    return json.loads((ROOT/'data/fixtures/positive_cases.json').read_text(encoding='utf8'))['cases']

if __name__=='__main__':
    unittest.main()
