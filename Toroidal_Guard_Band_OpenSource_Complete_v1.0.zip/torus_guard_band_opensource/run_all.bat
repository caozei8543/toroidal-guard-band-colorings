@echo off
setlocal
cd /d "%~dp0"
REM Check the pristine release hashes before any output regeneration.
python tools\verify_checksums.py || goto :bad
python run_audit.py --export-assignments --output data\generated || goto :bad
python verify_exports.py --input data\generated || goto :bad
python tools\compare_historical_results.py || goto :bad
python tools\compare_paper_tables.py || goto :bad
python -m unittest discover -s tests -v || goto :bad
echo ALL CHECKS PASSED
exit /b 0
:bad
echo FAILED: see output above
exit /b 1
