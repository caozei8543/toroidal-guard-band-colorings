from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from pathlib import Path

src=Path('/mnt/data/Access_Word_Template.docx')
out=Path('/mnt/data/Guard_Band_Toroidal_Minimal_Revision.docx')
doc=Document(src)
changes=[]

def change(part,old,new,slug):
  from itertools import accumulate
  nodes=part._element.xpath('.//w:t')
  alltext=''.join(n.text or '' for n in nodes)
  pos=alltext.find(old)
  if pos<0:
    raise AssertionError(f'NOT FOUND [{slug}]: {old} :: {alltext[:130]}')
  if alltext.count(old)!=1:raise AssertionError(f'nonunique {slug}')
  a,b=pos,pos+len(old)
  spans=[];cursor=0
  for i,n in enumerate(nodes):
    st,en=cursor,cursor+len(n.text or '')
    if en>a and st<b:spans.append((i,n,st,en))
    cursor=en
  assert spans
  ix0,n0,st0,en0=spans[0]; ix1,n1,st1,en1=spans[-1]
  prefix=(n0.text or '')[:max(0,a-st0)]
  suffix=(n1.text or '')[max(0,b-st1):]
  if n0 is n1:
    n0.text=prefix+new+suffix
  else:
    n0.text=prefix+new
    for _,mid,*_ in spans[1:-1]:mid.text=''
    n1.text=suffix
  changes.append((slug,old,new))

# Content precision: intervene only in review-sensitive phrases, do not rewrite proofs.
change(doc.paragraphs[7],
 'A complete Lee-interval phase separates local coloring feasibility from the congruences needed on a finite torus.',
 'A complete Lee-interval phase separates local injectivity from the congruences needed on a finite torus.',
 'abstract local-vs-global precision')
change(doc.paragraphs[7],
 'Our central exactness result combines a palette-saturation lower bound with explicit Lee-diameter cliques:',
 'Our central exactness result matches compressed Skolem constructions with a palette-saturation bound from Lee-diameter cliques:',
 'abstract upper/lower mechanism linkage')
change(doc.paragraphs[7],
 'for d congruent to 0 or 3 modulo 4',
 'for d ≥ 3 congruent to 0 or 3 modulo 4',
 'abstract explicit radius lower bound')
change(doc.paragraphs[26],
 'Under the necessary displayed phase congruences for the relevant quotient,',
 'Under the stated phase-closure congruences for the quotient,',
 'avoid necessary-for-all interpretation')
change(doc.paragraphs[66],
 'Figure 3 isolates this interface.',
 'Fig. 3 isolates this interface.',
 'IEEE figure citation consistency')
change(doc.paragraphs[152],
 'Given an undirected edge',
 'For an undirected edge',
 'avoid implying unordered edge has a canonical orientation')
change(doc.paragraphs[152],
 'recover the unique local step',
 'choose x as the reference endpoint and recover the unique local step',
 'make the edge-label orientation convention explicit')
change(doc.paragraphs[250],
 ' The author also thanks the anonymous reviewers and editors for their time and constructive comments.',
 '',
 'remove pre-review thanks')

# Replace static / obsolete template footers with automatic PAGE fields.
for secno,sec in enumerate(doc.sections):
  par=sec.footer.paragraphs[0]
  for r in list(par.runs):
    r._element.getparent().remove(r._element)
  par.paragraph_format.space_before=Pt(0)
  par.paragraph_format.space_after=Pt(0)
  par.add_run('\t')
  run=par.add_run()
  run.font.name='Helvetica';run.font.size=Pt(6)
  begin=OxmlElement('w:fldChar');begin.set(qn('w:fldCharType'),'begin')
  instr=OxmlElement('w:instrText');instr.set(qn('xml:space'),'preserve');instr.text=' PAGE '
  separate=OxmlElement('w:fldChar');separate.set(qn('w:fldCharType'),'separate')
  displayed=OxmlElement('w:t');displayed.text='1'
  end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end')
  for e in (begin,instr,separate,displayed,end):run._r.append(e)
  changes.append((f'section {secno} footer', 'static template footer', 'automatic PAGE field'))

# Remove stale published-template header words; retain any existing graphic/other elements.
par=doc.sections[1].header.paragraphs[0]
change(par,
 'Author Name: Preparation of Papers for IEEE Access (February 2017)',
 'Zhang: Exact Guard-Band Colorings of Toroidal Grid Powers',
 'replace stale sample running head')

doc.save(out)
print(out)
for slug,old,new in changes:print(slug, ':',repr(old[:100]),'=>',repr(new[:100]))
