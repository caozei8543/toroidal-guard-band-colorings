from docx import Document
from docx.oxml.ns import qn
src='/mnt/data/Guard_Band_Toroidal_Minimal_Revision.docx'
out='/mnt/data/Guard_Band_Toroidal_Layout_Trial.docx'
d=Document(src)
# Eq 1: remove unusual one-inch first line indent which forces the equation/number to be separated
p=d.paragraphs[14]
assert '(1)' in p.text
pPr=p._element.find(qn('w:pPr'))
ind=pPr.find(qn('w:ind'))
ind.set(qn('w:firstLine'),'0')
ind.set(qn('w:firstLineChars'),'0')
# Eq 17: move equation tag within actual column (instead of beyond the tab stop)
p=d.paragraphs[145]
assert '(17)' in p.text
for t in p._element.xpath('./w:pPr/w:tabs/w:tab'):
 if t.get(qn('w:val'))=='right':t.set(qn('w:pos'),'4440')
# Caption 7: remove verbatim repetition and keep it on the same page as figure
p=d.paragraphs[148]
assert 'The exceptional wrapped difference' in p.text
p.clear()
p.add_run('The wrapped pair (14, 3) realizes −11 ≡ 6 (mod 17); all twelve offsets lie in the admissible guard interval 3–14.')
d.save(out)
print(out)
