from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
p='/mnt/data/Guard_Band_Toroidal_Final_15pages.docx'
D=Document(p)
cell=D.tables[2].cell(0,3)
cell.text='[bₕ−aₕ]₁₇'
pr=cell.paragraphs[0]
pr.alignment=WD_ALIGN_PARAGRAPH.CENTER
for run in pr.runs:run.font.name='Cambria Math';run.font.size=Pt(9);run.font.color.rgb=None
D.save(p)
print('fixed table III col4 header')
