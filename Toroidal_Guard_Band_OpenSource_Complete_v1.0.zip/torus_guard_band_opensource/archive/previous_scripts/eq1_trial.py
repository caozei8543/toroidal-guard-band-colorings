from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
D=Document('/mnt/data/Guard_Band_Toroidal_Layout_Trial.docx')
p=D.paragraphs[14]
pPr=p._element.find(qn('w:pPr'))
tabs=pPr.find(qn('w:tabs'))
if tabs is None:
  tabs=OxmlElement('w:tabs')
  pPr.insert(1,tabs)
for val,pos in [('right','4380'),('clear','4584')]:
  elem=OxmlElement('w:tab');elem.set(qn('w:val'),val);elem.set(qn('w:pos'),pos)
  tabs.append(elem)
D.save('/mnt/data/Guard_Band_Toroidal_Layout_Trial2.docx')
