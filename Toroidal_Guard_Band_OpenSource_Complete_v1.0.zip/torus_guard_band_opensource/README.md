# Toroidal Grid Powers — Exact Guard-Band Coloring Reproduction Package

**English overview | 中文说明见 [README_中文.md](README_中文.md)**

This repository is the full, runnable reproduction bundle accompanying the manuscript **“Exact Guard-Band Colorings of Toroidal Grid Powers via Lee Cliques and Modular Difference Pairings”**, authored by **Weibiao Zhang** (manuscript version supplied by the author; no publication DOI is asserted).

It contains the complete source and logs from the previously reported **16 positive audit cases**, an additional **2 independently labeled supplemental positive cases** corresponding to the `d=4` rows of Table V, **6 explicit invalid-input rejection controls**, three finite Lee-diameter clique checks, every exported vertex and edge label in CSV form, difference-pair certificates, tests, independent CSV verification, and the final manuscript for comparison. The distinction between original and supplemental evidence is preserved explicitly in every machine-readable result.

## One-command reproduction (Python standard library only)

Requires **Python 3.10 or later**; tested here on Python 3.13.5. No `pip install`, external solver, dataset download, or internet access is required.

From the directory containing this README:

```bash
python run_audit.py --export-assignments --output data/generated
python verify_exports.py --input data/generated
python -m unittest discover -s tests -v
python tools/verify_checksums.py  # check pristine archive before regenerating outputs
```

**Important:** the checksum check compares the release against its original shipped files. Run it **before** regeneration; regenerated results may change harmless environment metadata (`platform.python`, architecture), and the existing checksums will then no longer match. For the original 16-case reproduction alone:

```bash
python run_audit.py --original-only --output /tmp/torus_original16
python archive/previous_scripts/torus_guard_band_independent_audit.py
```

On Windows, replace `/tmp/torus_original16` with a suitable local path or omit `--output`.

## Audited scope

| Group | Positive cases | Directed edge evaluations | Incident-edge pair comparisons | Result |
|---|---:|---:|---:|---|
| `original16` (historical) | 16 | 157,876 | 2,336,334 | 16/16 pass |
| `supplemental2` (additional d=4 tests) | 2 | 128,560 | 2,506,920 | 2/2 pass |
| **Both** | **18** | **286,436** | **4,843,254** | **18/18 pass** |

The 18 positive tests contain **143,218 undirected edges** in total. Six negative controls are separately tested for **correct rejection**, rather than counted as successful colorings. Three finite clique witnesses (`d=2,3,4`) have respective cardinalities **5, 8, 13**.

Every test uses **ordinary-integer** color differences, including both endpoint incidence checks and reverse-orientation edge labels. The **independent `verify_exports.py`** reconstructs the toroidal power edges and checks the generated CSV data without using the coloring constructors.

The finite tests validate explicit assignments on those instances; they **do not prove infinite-family claims, mathematical optimality, or novelty**. The manuscript's arguments for existence and lower bounds remain indispensable. No claim is made that an arbitrary torus can be colored optimally with these palettes.

## Repository map

| Path | Meaning |
|---|---|
| `src/guardband/core.py` | Constructive graph, phase, quotient-cover, offset, wrapped pairing, clique certificates, and complete numerical audit |
| `run_audit.py` | Reproducible 18-case runner; outputs JSON, CSV, full assignments, and expected failures |
| `verify_exports.py` | Independent, CSV-only second verification |
| `tests/test_certificates.py` | Eight standard-library test functions |
| `data/fixtures/positive_cases.json` | All parameters including original/supplemental provenance |
| `data/fixtures/negative_cases.json` | Three manuscript seam controls and three additional input-validation controls |
| `data/certificates/*.json` | Explicit hooked, ordinary and wrapped difference-pair tables (including order 20) |
| `data/generated/results.json`, `results.csv` | Every audit outcome and integer minimum separation margin |
| `data/generated/assignments/<case>/` | Per-case `vertices.csv`, `edges.csv`, `local_offsets.csv`, `summary.json` |
| `data/generated/lee_clique_witnesses.json` | Finite explicit clique vertices and pairwise-diameter checks |
| `logs/` | Full release audit stdout, independent CSV verification stdout, and unit-test stdout |
| `archive/previous_scripts`, `archive/previous_logs` | Original historical scripts and exact prior 16-case log; document-layout scripts are preserved but not part of the audit runtime |
| `manuscript/` | Author-supplied final Word/PDF manuscript (separate content rights) |
| `docs/` | Full data schema, equation mapping, reproducibility scope, audit memo |
| `SHA256SUMS.txt` | Release file-integrity manifest (excluding itself) |

## Exact definitions and conventions

The torus graph has vertex set `Z_n × Z_m`, with adjacency for distinct vertices at toroidal Lee (Manhattan) distance at most `d`; the released cases require `n,m ≥ 2d+1`. Its degree is `Δ=2d(d+1)`, and the linear phase is `λ(a,b)=d*a+(d+1)*b`. Guards `(r,s,t)` are lower bounds for, respectively, adjacent vertex labels, adjacent edge labels, and incident vertex–edge labels, all interpreted as **ordinary integer** distances.

Each output case preserves an explicit modulus and the required modular period closure, which are *sufficient conditions for that construction*, not necessary conditions for all possible colorings. The `hooked`, `ordinary`, and `wrapped` offsets are explicitly tabulated, and the reverse-generator identity is tested.

## Data and citations

See [docs/DATA_DICTIONARY.md](docs/DATA_DICTIONARY.md), [docs/METHOD_TO_PAPER.md](docs/METHOD_TO_PAPER.md), [docs/REPRODUCIBILITY.md](docs/REPRODUCIBILITY.md), and [CITATION.cff](CITATION.cff). For detailed mathematical justifications consult the manuscript's Theorems 1–6 and Lemmas 1–5. Dataset values are generated exactly by the included code; all auditing arithmetic is integer-only.

## License and publication caution

The software, JSON/CSV fixtures, generated numerical data, logs, and documentation authored for this package are released under the [MIT License](LICENSE) **subject to the rightsholder's review**. The manuscript's Word/PDF files are **not** licensed under MIT: they remain with the manuscript's copyright holder and may be subject to publisher policies. Confirm ownership, any coauthor consent, manuscript-release permissions and desired license before making a public repository. See [RELEASE_NOTES.md](RELEASE_NOTES.md).

This software is provided without warranty. No exact-coloring theorem should be inferred solely from finite tests.

## GitHub CI and convenient launchers

Run `bash run_all.sh` on macOS/Linux or `run_all.bat` on Windows to perform the pre-regeneration hash check, export and independent verification, both paper/log comparison scripts, and all tests. `.github/workflows/reproduce.yml` adds equivalent checks on pushes and pull requests. The helper scripts `tools/compare_historical_results.py` and `tools/compare_paper_tables.py` cross-check **all** 16 historical log records and each row of the manuscript's Tables V–VI. These historical summaries are explicitly versioned as CSV in `data/fixtures/`.
